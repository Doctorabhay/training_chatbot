/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from "react";
import { AudioStreamer } from "../utils/AudioStreamer";

interface WaveformVisualizerProps {
  streamer: AudioStreamer | null;
  state: "disconnected" | "connecting" | "idle" | "listening" | "speaking";
}

export const WaveformVisualizer: React.FC<WaveformVisualizerProps> = ({ streamer, state }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const animationRef = useRef<number | null>(null);
  const phaseRef = useRef<number>(0);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Resize handler to support responsive viewport
    const handleResize = () => {
      const rect = canvas.getBoundingClientRect();
      canvas.width = rect.width * window.devicePixelRatio;
      canvas.height = rect.height * window.devicePixelRatio;
      ctx.scale(window.devicePixelRatio, window.devicePixelRatio);
    };

    handleResize();
    window.addEventListener("resize", handleResize);

    const dataArray = new Uint8Array(128);

    const draw = () => {
      const width = canvas.width / window.devicePixelRatio;
      const height = canvas.height / window.devicePixelRatio;
      ctx.clearRect(0, 0, width, height);

      phaseRef.current += 0.05; // speed parameter for default animations

      // 1. DISCONNECTED state: simple thin flat line with noise
      if (state === "disconnected") {
        ctx.beginPath();
        ctx.strokeStyle = "rgba(100, 116, 139, 0.4)"; // muted grey slate
        ctx.lineWidth = 1.5;
        for (let i = 0; i < width; i++) {
          const x = i;
          const y = height / 2 + Math.sin(i * 0.05 + phaseRef.current) * 0.8;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }

      // 2. CONNECTING state: spinning high-speed orbital loops
      else if (state === "connecting") {
        const centerX = width / 2;
        const centerY = height / 2;
        const radius = Math.min(width, height) * 0.25;

        ctx.beginPath();
        ctx.strokeStyle = "rgba(139, 92, 246, 0.2)"; // faint violet
        ctx.lineWidth = 1.5;
        ctx.arc(centerX, centerY, radius, 0, Math.PI * 2);
        ctx.stroke();

        ctx.beginPath();
        const startAngle = phaseRef.current * 1.5;
        const endAngle = startAngle + Math.PI * 0.5;
        ctx.strokeStyle = "rgba(167, 139, 250, 0.9)"; // bright violet
        ctx.lineWidth = 3;
        ctx.arc(centerX, centerY, radius, startAngle, endAngle);
        ctx.stroke();

        // Pulsing core
        ctx.beginPath();
        ctx.fillStyle = "rgba(192, 132, 252, 0.3)";
        ctx.arc(centerX, centerY, radius * 0.4 + Math.sin(phaseRef.current * 4) * 4, 0, Math.PI * 2);
        ctx.fill();
      }

      // 3. IDLE state: gentle glowing breathing sine waves
      else if (state === "idle") {
        ctx.lineWidth = 2.5;

        // Draw multiple overlapping sine waves with different phases
        const waves = [
          { amplitude: 12, frequency: 0.015, offset: phaseRef.current * 0.5, color: "rgba(6, 182, 212, 0.4)" }, // cyan
          { amplitude: 8, frequency: 0.02, offset: phaseRef.current * 0.8 + 2, color: "rgba(139, 92, 246, 0.3)" }, // violet
          { amplitude: 18, frequency: 0.01, offset: phaseRef.current * 0.3 + 4, color: "rgba(236, 72, 153, 0.25)" }, // hot pink
        ];

        waves.forEach((wave) => {
          ctx.beginPath();
          ctx.strokeStyle = wave.color;
          for (let i = 0; i < width; i++) {
            const x = i;
            const y = height / 2 + Math.sin(i * wave.frequency + wave.offset) * wave.amplitude * Math.sin((i / width) * Math.PI);
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
          }
          ctx.stroke();
        });
      }

      // 4. LISTENING state: responsive mic-frequency spikes
      else if (state === "listening") {
        let hasActiveData = false;
        if (streamer && streamer.micAnalyser) {
          streamer.micAnalyser.getByteFrequencyData(dataArray);
          hasActiveData = true;
        }

        ctx.beginPath();
        ctx.strokeStyle = "rgba(34, 211, 238, 0.85)"; // vibrant cyan
        ctx.lineWidth = 2;

        const sliceWidth = width / 60;
        ctx.moveTo(0, height / 2);

        for (let i = 0; i < 60; i++) {
          const index = Math.floor((i / 60) * dataArray.length * 0.8);
          const magnitude = hasActiveData ? dataArray[index] : 0;
          const amp = (magnitude / 255.0) * (height * 0.5); // responsive height

          const x = i * sliceWidth + sliceWidth * 0.5;
          const yOffset = Math.sin(phaseRef.current * 2 + i * 0.1) * 3; // ambient wiggle
          const y = height / 2 + (i % 2 === 0 ? amp : -amp) + yOffset;

          ctx.lineTo(x, y);
        }
        ctx.stroke();

        // Draw radial mirror shadow to make it feel cybernetic
        ctx.beginPath();
        ctx.strokeStyle = "rgba(139, 92, 246, 0.4)"; // purple reflection
        ctx.lineWidth = 1;
        for (let i = 0; i < 60; i++) {
          const index = Math.floor((i / 60) * dataArray.length * 0.8);
          const magnitude = hasActiveData ? dataArray[index] : 0;
          const amp = (magnitude / 255.0) * (height * 0.25);
          const x = i * sliceWidth + sliceWidth * 0.5;
          const y = height / 2 - (i % 2 === 0 ? amp : -amp);
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }

      // 5. SPEAKING state: glowing sassy speaker voice frequencies
      else if (state === "speaking") {
        let hasActiveData = false;
        if (streamer && streamer.speakerAnalyser) {
          streamer.speakerAnalyser.getByteTimeDomainData(dataArray);
          hasActiveData = true;
        } else {
          // Fallback if no analyzer is bound yet
          for (let i = 0; i < dataArray.length; i++) {
            dataArray[i] = 128 + Math.sin(i * 0.15 + phaseRef.current * 1.5) * 35;
          }
          hasActiveData = true;
        }

        ctx.lineWidth = 3;
        ctx.shadowBlur = 12;
        ctx.shadowColor = "rgba(236, 72, 153, 0.8)"; // hot pink cyber glow

        // Draw primary vocal track with hot pink
        ctx.beginPath();
        ctx.strokeStyle = "rgba(236, 72, 153, 0.95)"; // pink
        for (let i = 0; i < width; i++) {
          const dataIndex = Math.floor((i / width) * dataArray.length);
          const v = dataArray[dataIndex] / 128.0; // 0.0 to 2.0
          const amp = (v - 1.0) * (height * 0.45);
          const x = i;
          const y = height / 2 + amp * Math.sin((i / width) * Math.PI); // restrict to center

          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();

        ctx.shadowBlur = 0; // reset shadow for overlays

        // Draw backing energy track with purple
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.strokeStyle = "rgba(167, 139, 250, 0.7)"; // purple secondary
        for (let i = 0; i < width; i++) {
          const dataIndex = Math.floor((i / width) * dataArray.length);
          const v = dataArray[dataIndex] / 128.0;
          const amp = (v - 1.0) * (height * 0.28);
          const x = i;
          const y = height / 2 + amp * Math.sin((i / width) * Math.PI + Math.PI * 0.25) * -1;

          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.stroke();
      }

      animationRef.current = requestAnimationFrame(draw);
    };

    draw();

    return () => {
      window.removeEventListener("resize", handleResize);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [streamer, state]);

  return (
    <div id="visualizer-wrapper" className="relative w-full h-48 select-none">
      <canvas
        id="waveform-canvas"
        ref={canvasRef}
        className="w-full h-full block"
        style={{ pointerEvents: "none" }}
      />
      {/* Decorative center ambient orb indicator */}
      {state === "speaking" && (
        <div className="absolute inset-0 m-auto w-24 h-24 rounded-full bg-pink-500/20 blur-2xl animate-pulse" />
      )}
      {state === "listening" && (
        <div className="absolute inset-0 m-auto w-24 h-24 rounded-full bg-cyan-500/20 blur-2xl animate-pulse" />
      )}
    </div>
  );
};
