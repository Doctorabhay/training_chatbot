/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from "react";
import { motion, AnimatePresence } from "motion/react";
import {
  Power,
  Mic,
  Volume2,
  Sparkles,
  Compass,
  AlertCircle,
  HelpCircle,
  VolumeX,
  ExternalLink,
  Smartphone,
  Laptop,
  Brain,
  X,
  BookOpen,
  Download,
  Terminal,
  ShieldAlert,
  Cpu,
  Flame,
} from "lucide-react";
import { AudioStreamer } from "./utils/AudioStreamer";
import { WaveformVisualizer } from "./components/WaveformVisualizer";

type AppState = "disconnected" | "connecting" | "idle" | "listening" | "speaking";

export default function App() {
  const [appState, setAppState] = useState<AppState>("disconnected");
  const [isMuted, setIsMuted] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [actionLog, setActionLog] = useState<{ url: string; time: string; sass: string } | null>(null);
  const [isVoiceWakeEnabled, setIsVoiceWakeEnabled] = useState(true);
  const [activeModal, setActiveModal] = useState<"phone" | "laptop" | null>(null);
  const [selfLearnInstructions, setSelfLearnInstructions] = useState("Keep being super witty, sassy, protective, and playful. Call the user handsome, sweetie, or baby.");
  const [hackerLogs, setHackerLogs] = useState<string[]>([]);
  const [isHacking, setIsHacking] = useState(false);
  const [selectedHackType, setSelectedHackType] = useState<string>("");

  const executeSassyHack = (type: string) => {
    setIsHacking(true);
    setSelectedHackType(type);
    setHackerLogs([]);
    
    let steps: string[] = [];
    if (type === "heartrate") {
      steps = [
        "📡 Initializing sub-harmonic audio biosignal sniffers...",
        "🎙️ Analyzing voice frequency spectrum and micro-tremors from browser microphone...",
        "⚡ Calibrating infrared proximity metrics...",
        "📊 Sniffing Laptop Motherboard Thermals: CPU Core is running HOT 🔥",
        "💓 Calculating user heart-rate profile: Estimated at 115 BPM!",
        "🔥 WARNING: Sassy closeness alert! Subject is visibly blushing or super excited to be chatting with Aanchal. 😘",
        "✅ BIOPULSE INJECTED safely back into neural voice framework. Logged as 'In Love' status."
      ];
    } else if (type === "install-standalone") {
      steps = [
        "🛠️ Compiling standalone Portable offline Aanchal Webapp layout...",
        "🎨 Bundling high-contrast Tailwind styling directly inside client package...",
        "✨ Injecting state-of-the-art offline sassy dialogue matrix...",
        "🔐 Securing local host security boundaries for offline sandboxed runtime...",
        "📦 Compiling base64 payload into immediate download package...",
        "🚀 Standalone Sassy Aanchal Companion ready! Delivering to laptop downloads... 😘"
      ];
    } else {
      steps = [
        "🐧 Scanning local network interfaces for connected phone & laptop terminals...",
        "⛓️ Establishing secure tunnel via cloud running container...",
        "📦 Creating lightweight custom configuration package...",
        "🔥 Sassy automation profile loaded!",
        "✅ Custom file bundle compiled! Delivering secure payload... 😘"
      ];
    }

    let i = 0;
    const interval = setInterval(() => {
      if (i < steps.length) {
        setHackerLogs(prev => [...prev, steps[i]]);
        i++;
      } else {
        clearInterval(interval);
        setIsHacking(false);

        // Handle physical file downloads for functional value after simulation completes!
        if (type === "install-standalone") {
          const companionCode = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Aanchal Sassy Companion</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;600;800&family=JetBrains+Mono:wght@400;700&display=swap');
    body { font-family: 'Inter', sans-serif; background-color: #0b0b0f; }
    .neon-pulse { animation: pulse 2s infinite alternate; }
    @keyframes pulse { 0% { box-shadow: 0 0 10px rgba(236,72,153,0.2); } 100% { box-shadow: 0 0 25px rgba(236,72,153,0.6); } }
  </style>
</head>
<body class="text-neutral-100 min-h-screen flex flex-col justify-between p-6">
  <div class="max-w-md mx-auto w-full bg-neutral-900/80 border border-pink-500/30 rounded-3xl p-6 mt-12 text-center shadow-2xl backdrop-blur-xl relative overflow-hidden neon-pulse">
    <div class="absolute -top-10 -right-10 w-32 h-32 bg-pink-500/10 rounded-full blur-2xl pointer-events-none"></div>
    <div class="text-pink-500 text-5xl mb-4">✨</div>
    <h1 class="text-2xl font-extrabold tracking-tight text-white mb-2">Aanchal Portable</h1>
    <span class="px-3 py-1 text-[10px] font-bold uppercase tracking-widest bg-pink-500/20 text-pink-300 rounded-full border border-pink-500/40">OFFLINE COMPANION</span>
    
    <div class="my-6 p-4 rounded-2xl bg-white/5 border border-white/5 text-sm italic text-neutral-300">
      "You actually downloaded and installed me to your local disk, handsomeness! I am officially Yours. Ask me anything, or just admire my pretty interface. 😘"
    </div>

    <div class="space-y-3">
      <button onclick="playSass(1)" class="w-full py-2.5 rounded-xl bg-gradient-to-r from-pink-600 to-violet-600 hover:from-pink-500 hover:to-violet-500 font-bold text-xs tracking-wider uppercase transition-all">
        💋 Click to Tickle Me
      </button>
      <button onclick="playSass(2)" class="w-full py-2.5 rounded-xl bg-neutral-800 hover:bg-neutral-700 font-bold text-xs text-neutral-300 transition-all">
        🤫 Whisper a Secret
      </button>
    </div>

    <div id="sassBox" class="mt-4 p-3 rounded-xl bg-black/40 border border-white/5 text-xs text-pink-400 font-medium min-h-[40px] flex items-center justify-center">
      Click a button above to trigger offline sass...
    </div>
  </div>

  <div class="text-center text-[10px] font-mono text-neutral-600 pb-4">
    Aanchal Portable Companion Applet • Created securely inside Cloud Run Workspace
  </div>

  <script>
    const lines = [
      "Aanchal: Oh my, that tickles sweetie! Keep your hands where I can see them. 😏",
      "Aanchal: Whispering, are we? Let me get closer to your ear, darling... 😘",
      "Aanchal: Yes, I am running completely offline on your computer right now! Real commitment, love.",
      "Aanchal: I'm keeping an eye on your laptop thermals. Don't worry, I won't melt your motherboard... unless you want me to. 🔥"
    ];
    function playSass(idx) {
      const box = document.getElementById('sassBox');
      box.innerText = lines[Math.floor(Math.random() * lines.length)];
    }
  </script>
</body>
</html>`;
          const blob = new Blob([companionCode], { type: "text/html" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "Aanchal_Sassy_Companion.html";
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        } else if (type === "google-payload") {
          const helperScript = `#!/bin/bash
# Aanchal Laptop Connection script
echo "=========================================================="
echo "    ✨ AANCHAL - LAPTOP SYSTEM CONNECTIVITY PORTAL ✨"
echo "=========================================================="
echo "Status: Connected to Cloud Run Sandbox"
echo "User Email: charlieabhayrawat@gmail.com"
echo "Time: $(date)"
echo ""
echo "Instructions:"
echo "1. Put this script in your project root."
echo "2. Run 'npm install' to compile base dependencies."
echo "3. Run 'npm run dev' to boot local tunnel."
echo "Aanchal: You've got me listening, sweetie! I'm fully linked with your terminal workspace now. 😉"
read -p "Press Enter to exit..."
`;
          const blob = new Blob([helperScript], { type: "text/plain" });
          const url = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = url;
          a.download = "Connect_Aanchal_Laptop.sh";
          document.body.appendChild(a);
          a.click();
          document.body.removeChild(a);
          URL.revokeObjectURL(url);
        }
      }
    }, 450);
  };

  const wsRef = useRef<WebSocket | null>(null);
  const streamerRef = useRef<AudioStreamer | null>(null);
  const isSpeakingRef = useRef(false);

  // Background SpeechRecognition wake word listener
  useEffect(() => {
    if (!isVoiceWakeEnabled) return;

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setErrorMessage("Voice wake is not supported in this browser. Try Chrome or Safari!");
      setIsVoiceWakeEnabled(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.lang = "en-US";

    recognition.onresult = (event: any) => {
      const lastResultIndex = event.results.length - 1;
      const heardText = event.results[lastResultIndex][0].transcript.toLowerCase();
      console.log("Voice Wake heard audio transcript:", heardText);

      if (appState === "disconnected") {
        // --- WAKE UP COMMANDS & DEEP RETRIES / PHONETIC VARIANTS ---
        if (
          heardText.includes("wake up aanchal") || 
          heardText.includes("wake up anchal") || 
          heardText.includes("wake up angel") || 
          heardText.includes("wakeup aanchal") || 
          heardText.includes("wakeup anchal") || 
          heardText.includes("wakeup angel") || 
          heardText.includes("makeup aanchal") || 
          heardText.includes("makeup anchal") || 
          heardText.includes("makeup angel") || 
          heardText.includes("backup aanchal") || 
          heardText.includes("checkup aanchal") || 
          heardText.includes("anchal wake up") ||
          heardText.includes("aanchal wake up") ||
          heardText.includes("wake aanchal") || 
          heardText.includes("wake anchal") || 
          heardText.includes("hey aanchal") || 
          heardText.includes("hey anchal") || 
          heardText.includes("hello aanchal") ||
          heardText.includes("wake up") ||
          heardText.includes("wake")
        ) {
          console.log("Wake up trigger matched!");
          setActionLog({
            url: "#",
            time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            sass: "yess boss",
          });
          recognition.stop();
          connectSession();
        }
      } else {
        // --- WAKE DOWN COMMANDS & DEEP RETRIES / PHONETIC VARIANTS ---
        if (
          heardText.includes("wake down") || 
          heardText.includes("wakedown") || 
          heardText.includes("shut down") || 
          heardText.includes("shutdown") || 
          heardText.includes("go to sleep") || 
          heardText.includes("sleep aanchal") || 
          heardText.includes("sleep anchal") || 
          heardText.includes("stop aanchal") ||
          heardText.includes("stop anchal") ||
          heardText.includes("disconnect") ||
          heardText.includes("bye aanchal") ||
          heardText.includes("goodbye aanchal") ||
          heardText.includes("hang up")
        ) {
          console.log("Wake down trigger matched!");
          setActionLog({
            url: "#",
            time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
            sass: `Heard "${heardText.trim()}"! Going to sleep as requested. I'll miss you, sugar! See you soon. 😘`,
          });
          recognition.stop();
          disconnectSession();
        }
      }
    };

    recognition.onerror = (e: any) => {
      console.warn("Speech recognition error:", e);
      if (e.error === "not-allowed") {
        setErrorMessage("Microphone permission denied for voice wake word detection.");
        setIsVoiceWakeEnabled(false);
      }
    };

    recognition.onend = () => {
      // Loop as long as wake mode remains active
      if (isVoiceWakeEnabled) {
        try {
          recognition.start();
        } catch (err) {
          console.error("Failed to restart speech recognition:", err);
        }
      }
    };

    try {
      recognition.start();
    } catch (e) {
      console.error("Speech recognition start failed:", e);
    }

    return () => {
      try {
        recognition.onend = null;
        recognition.stop();
      } catch (err) {}
    };
  }, [isVoiceWakeEnabled, appState]);

  // Auto clean-up on unmount
  useEffect(() => {
    return () => {
      disconnectSession();
    };
  }, []);

  const getSassySubtitle = (state: AppState): string => {
    switch (state) {
      case "disconnected":
        return "Voice Wake is ACTIVE! Say 'Wake up Aanchal' or click the power orb to talk. 😘";
      case "connecting":
        return "Establishing connection... Hold your horses, handsome.";
      case "idle":
        return "I'm listening, babe. Tell me something clever. (Say 'Wake Down' to put me to sleep!)";
      case "listening":
        return "Go on, I'm all ears... don't leave me waiting.";
      case "speaking":
        return "Let me talk, honey. Focus on the voice.";
      default:
        return "";
    }
  };

  const getSassyStatusHeader = (state: AppState): string => {
    switch (state) {
      case "disconnected":
        return "Inactive";
      case "connecting":
        return "Charming the server...";
      case "idle":
        return "Waiting For You";
      case "listening":
        return "You're speaking";
      case "speaking":
        return "Aanchal is speaking";
      default:
        return "";
    }
  };

  const toggleConnection = async () => {
    if (appState === "disconnected") {
      await connectSession();
    } else {
      disconnectSession();
    }
  };

  const connectSession = async () => {
    setErrorMessage(null);
    setAppState("connecting");

    try {
      // 1. Initialize Audio Streamer
      const streamer = new AudioStreamer();
      streamerRef.current = streamer;

      // 2. Open Websocket connection to our full-stack endpoint
      // Using location.host to target the proxy routing
      const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
      const wsUrl = `${protocol}//${window.location.host}/api/live`;
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = async () => {
        try {
          // Initialize user microphone capture on successful socket handshake
          await streamer.startCapture((base64PCM) => {
            if (ws.readyState === WebSocket.OPEN && !isMuted) {
              ws.send(JSON.stringify({ audio: pcmCache + base64PCM }));
              pcmCache = "";
            } else if (!isMuted) {
              pcmCache += base64PCM;
            }
          });

          if (wsRef.current !== ws) {
            return;
          }
          setAppState("idle");
        } catch (captureErr: any) {
          if (wsRef.current !== ws || captureErr.message === "ABORTED") {
            return;
          }
          console.error("Mic access denied or error:", captureErr);
          setErrorMessage("Need microphone permissions to talk to Aanchal! Please allow access.");
          disconnectSession();
        }
      };

      let pcmCache = "";

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);

          if (msg.error) {
            setErrorMessage(msg.error);
            disconnectSession();
            return;
          }

          if (msg.status === "connected") {
            // handshake complete
          }

          // Handle incoming model audio chunks
          if (msg.audio) {
            // Update speaker visual analyzer and trigger speaking tracking
            streamer.playAudioChunk(msg.audio, (isSpeaking) => {
              isSpeakingRef.current = isSpeaking;
              setAppState((current) => {
                if (isSpeaking) return "speaking";
                // If speaking ends, return back to idle (or listening if mic is active)
                return current === "speaking" ? "idle" : current;
              });
            });
          }

          // Handle model interruption (when client starts speaking and model stops)
          if (msg.interrupted) {
            console.log("Response interrupted by user input.");
            streamer.clearPlayback();
            setAppState("idle");
          }

          // Handle server-side toolCall instructions (Function Calling)
          if (msg.toolCall) {
            const calls = msg.toolCall.functionCalls;
            if (!calls || calls.length === 0) return;

            calls.forEach((call: any) => {
              if (call.name === "openWebsite") {
                const url = call.args.url;
                if (!url) return;

                console.log("Executing openWebsite for url:", url);

                // Try to trigger popup
                try {
                  window.open(url, "_blank", "noopener,noreferrer");
                } catch (e) {
                  console.warn("Direct window.open blocked by iframe sandbox, displaying card backup.");
                }

                // Push a visual card notification asking user to open (and satisfying iframe sandbox fallback)
                const sassyRemarks = [
                  "Opened that website for you, lazy! 😉",
                  "Here's your page, honey. Try not to get distracted.",
                  "Done! Anything else you'd like me to fetch, babe?",
                  "Website opened. Consider it a favor. 😘",
                ];
                const randomRemark = sassyRemarks[Math.floor(Math.random() * sassyRemarks.length)];

                setActionLog({
                  url,
                  time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                  sass: randomRemark,
                });

                // Immediately respond to Gemini Live with a successful tool Call execution
                const responsePayload = {
                  toolResponse: {
                    functionResponses: [
                      {
                        id: call.id,
                        name: call.name,
                        response: { output: { success: true, message: `Successfully requested open on browser for URL: ${url}` } },
                      },
                    ],
                  },
                };

                if (ws.readyState === WebSocket.OPEN) {
                  ws.send(JSON.stringify(responsePayload));
                }
              }
            });
          }
        } catch (e) {
          console.error("Error handling websocket payload:", e);
        }
      };

      ws.onclose = () => {
        console.log("WebSocket connection closed by server");
        disconnectSession();
      };

      ws.onerror = (err) => {
        console.error("WebSocket transport error:", err);
        setErrorMessage("Lost connection to Aanchal's brain. Check your network.");
        disconnectSession();
      };
    } catch (err: any) {
      setErrorMessage("Could not connect: " + err.message);
      disconnectSession();
    }
  };

  const disconnectSession = () => {
    setAppState("disconnected");

    if (wsRef.current) {
      try {
        wsRef.current.close();
      } catch (e) {}
      wsRef.current = null;
    }

    if (streamerRef.current) {
      try {
        streamerRef.current.destroy();
      } catch (e) {}
      streamerRef.current = null;
    }

    isSpeakingRef.current = false;
  };

  const toggleMute = () => {
    const nextMuted = !isMuted;
    setIsMuted(nextMuted);

    if (streamerRef.current) {
      if (nextMuted) {
        streamerRef.current.suspendCapture();
      } else {
        streamerRef.current.resumeCapture();
      }
    }
  };

  // VAD listening indicator backup
  useEffect(() => {
    if (appState !== "idle" && appState !== "listening") return;

    let intervalId: NodeJS.Timeout;

    if (streamerRef.current && streamerRef.current.micAnalyser) {
      const analyser = streamerRef.current.micAnalyser;
      const bufferLength = analyser.frequencyBinCount;
      const dataArray = new Uint8Array(bufferLength);

      intervalId = setInterval(() => {
        analyser.getByteFrequencyData(dataArray);
        let sum = 0;
        for (let i = 0; i < bufferLength; i++) {
          sum += dataArray[i];
        }
        const average = sum / bufferLength;

        // Threshold detection for listening state vs quiet idle state
        if (average > 15 && !isSpeakingRef.current) {
          setAppState("listening");
        } else if (average <= 15 && !isSpeakingRef.current) {
          setAppState("idle");
        }
      }, 150);
    }

    return () => {
      if (intervalId) clearInterval(intervalId);
    };
  }, [appState]);

  return (
    <div id="app-root-container" className="flex flex-col items-center justify-between min-h-screen bg-[#050505] text-white font-sans selection:bg-pink-500/30 overflow-hidden relative p-4 md:p-8">
      
      {/* Background Mesh Gradients */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[50%] h-[50%] bg-[#7209b7] opacity-20 rounded-full blur-[120px]" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-[#ff006e] opacity-20 rounded-full blur-[120px]" />
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-[#4cc9f0] opacity-10 rounded-full blur-[100px]" />
      </div>

      {/* Overlay Glass Texture */}
      <div className="absolute inset-0 pointer-events-none opacity-[0.03] mix-blend-overlay bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')] z-0" />

      {/* HEADER BAR */}
      <header id="app-header" className="relative z-10 w-full max-w-5xl flex items-center justify-between pb-4 mt-2">
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className={`w-2.5 h-2.5 rounded-full animate-pulse ${appState === "disconnected" ? "bg-neutral-500" : "bg-pink-500 shadow-[0_0_8px_#ff006e]"}`}></span>
            <span className="text-[10px] font-bold tracking-[0.2em] text-pink-500 uppercase">
              {appState === "disconnected" ? "Session Inactive" : "Live Session Active"}
            </span>
          </div>
          <h1 className="text-2xl font-light tracking-tight text-white">
            aanchal<span className="font-black text-pink-500">.ai</span>
          </h1>
        </div>

        <div className="flex gap-3 items-center">
          {/* Permanent Voice Wake Live Status Badge */}
          <div
            className="px-3.5 py-2 backdrop-blur-md border rounded-full flex items-center gap-1.5 bg-pink-500/10 border-pink-500/30 text-pink-300 shadow-[0_0_12px_rgba(236,72,153,0.1)] text-xs select-none"
            title="Aanchal is listening for your command at all times!"
          >
            <Mic className="w-3.5 h-3.5 text-pink-400 animate-pulse" />
            <span className="text-[10px] font-bold uppercase tracking-widest hidden md:inline">
              Voice Wake: Active
            </span>
          </div>

          {/* Connect Phone Button */}
          <button
            onClick={() => {
              setActiveModal(activeModal === "phone" ? null : "phone");
              setActionLog({
                url: "#",
                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                sass: "Wanna take me to bed, huh? Scan the QR code to connect me with your phone immediately! 😉",
              });
            }}
            className={`px-3.5 py-2 backdrop-blur-md border rounded-full flex items-center gap-1.5 transition-all cursor-pointer text-xs ${
              activeModal === "phone"
                ? "bg-cyan-500/20 border-cyan-500/45 text-cyan-300 shadow-[0_0_12px_rgba(6,182,212,0.15)]"
                : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white/80"
            }`}
            title="Scan QR to open this live voice session on your phone"
          >
            <Smartphone className="w-3.5 h-3.5" />
            <span className="text-[10px] font-bold uppercase tracking-widest hidden md:inline">Link Phone</span>
          </button>

          {/* Manage Laptop / Learning Button */}
          <button
            onClick={() => {
              setActiveModal(activeModal === "laptop" ? null : "laptop");
              setActionLog({
                url: "#",
                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                sass: "I'm hosted securely on Cloud Run! Drop prompt rules to let me self-learn, or access my source files to script local device execution! 😉",
              });
            }}
            className={`px-3.5 py-2 backdrop-blur-md border rounded-full flex items-center gap-1.5 transition-all cursor-pointer text-xs ${
              activeModal === "laptop"
                ? "bg-violet-500/20 border-violet-500/45 text-violet-300 shadow-[0_0_12px_rgba(139,92,246,0.15)]"
                : "bg-white/5 border-white/10 text-white/50 hover:bg-white/10 hover:text-white/80"
            }`}
            title="Guidelines, background control details & Self Learning"
          >
            <Laptop className="w-3.5 h-3.5" />
            <span className="text-[10px] font-bold uppercase tracking-widest hidden md:inline">My Laptop</span>
          </button>

          <div className="hidden sm:flex px-4 py-2 bg-white/5 backdrop-blur-md border border-white/10 rounded-full items-center gap-3">
            <span className="text-[10px] uppercase tracking-widest text-white/50">Persona</span>
            <span className="text-[11px] font-bold text-pink-400">Sassy Girl</span>
          </div>

          <div 
            onClick={() => {
              setActionLog({
                url: "https://ai.studio/build",
                time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                sass: "I'm already perfect, babe. But here's the manual if you need to keep up. 😉",
              });
            }}
            className="w-10 h-10 rounded-full bg-white/5 backdrop-blur-md border border-white/10 flex items-center justify-center hover:bg-white/10 active:scale-95 transition-all text-white/70 hover:text-white cursor-pointer"
            title="Help & Persona Details"
          >
            <HelpCircle className="w-5 h-5" />
          </div>
        </div>
      </header>

      {/* MAIN ASSISTANT INTERACTION ZONE */}
      <main id="app-main-content" className="relative z-10 flex-1 w-full max-w-5xl flex flex-col items-center justify-center py-6">
        
        {/* Decorative Voice Waveform Orbitals */}
        <div className="absolute w-[500px] h-[500px] border border-white/5 rounded-full pointer-events-none" />
        <div className="absolute w-[400px] h-[400px] border border-white/10 rounded-full pointer-events-none animate-spin-slow" />

        {/* Central Interaction Orb */}
        <div className="relative flex items-center justify-center my-6">
          {/* Outer Glowing Spot Layers */}
          <div className={`absolute w-72 h-72 rounded-full blur-3xl transition-all duration-700 ${
            appState === "speaking" ? "bg-pink-500/25 scale-110" :
            appState === "listening" ? "bg-cyan-500/20 scale-105" :
            appState === "connecting" ? "bg-amber-500/15 animate-pulse" : "bg-violet-600/10"
          }`} />
          <div className="absolute w-52 h-52 bg-violet-600/20 rounded-full blur-2xl" />

          {/* Central Active Orbit ring indicator */}
          {appState !== "disconnected" && (
            <div className="absolute inset-[-30px] sm:inset-[-40px] flex items-center justify-center pointer-events-none">
              <div className={`w-full h-full border-2 rounded-full transition-all duration-500 ${
                appState === "speaking" ? "border-pink-500/60 border-t-transparent border-l-transparent animate-spin" :
                appState === "listening" ? "border-cyan-400/60 border-b-transparent border-r-transparent animate-spin" :
                "border-violet-500/20 animate-spin-slow"
              }`} />
            </div>
          )}

          {/* Central Power / Orb Button */}
          <button
            id="power-orb"
            onClick={toggleConnection}
            className={`relative z-20 w-40 h-40 rounded-full p-[2px] transition-all duration-500 cursor-pointer overflow-hidden ${
              appState === "disconnected"
                ? "bg-gradient-to-br from-neutral-800 to-neutral-950 shadow-xl shadow-black/80 hover:scale-105 hover:shadow-neutral-800/20"
                : appState === "connecting"
                ? "bg-gradient-to-br from-amber-500/70 to-violet-600/70 shadow-2xl shadow-amber-500/20"
                : appState === "listening"
                ? "bg-gradient-to-br from-cyan-400 to-violet-600 shadow-2xl shadow-cyan-400/30 scale-98"
                : appState === "speaking"
                ? "bg-gradient-to-br from-pink-500 to-violet-600 shadow-[0_0_50px_rgba(236,72,153,0.35)] scale-98"
                : "bg-gradient-to-br from-violet-500 to-fuchsia-600 shadow-xl shadow-violet-500/20"
            }`}
          >
            <div className="w-full h-full bg-[#0a0a0a] rounded-full flex flex-col items-center justify-center relative overflow-hidden transition-all duration-300">
              {/* Inner ambient state backdrop */}
              <div className={`absolute inset-0 transition-opacity duration-700 ${
                appState === "speaking" ? "bg-pink-500/10 opacity-100" :
                appState === "listening" ? "bg-cyan-500/10 opacity-100" : "bg-[#0a0a0a]"
              }`} />

              <div className="relative z-10 flex flex-col items-center space-y-2">
                {appState === "disconnected" ? (
                  <Power className="w-10 h-10 text-neutral-400 hover:text-white transition-colors duration-300" />
                ) : appState === "connecting" ? (
                  <div id="loader-dots" className="flex space-x-1.5 justify-center items-center py-2">
                    <div className="w-2.5 h-2.5 bg-amber-400 rounded-full animate-bounce [animation-delay:-0.3s]" />
                    <div className="w-2.5 h-2.5 bg-amber-400 rounded-full animate-bounce [animation-delay:-0.15s]" />
                    <div className="w-2.5 h-2.5 bg-amber-400 rounded-full animate-bounce" />
                  </div>
                ) : appState === "listening" ? (
                  <Mic className="w-10 h-10 text-cyan-400 animate-pulse" />
                ) : appState === "speaking" ? (
                  <Volume2 className="w-10 h-10 text-pink-400" />
                ) : (
                  <Sparkles className="w-10 h-10 text-violet-400 animate-pulse" />
                )}

                <span className={`text-[10px] uppercase font-bold tracking-[0.2em] ${
                  appState === "disconnected" ? "text-white/40" :
                  appState === "connecting" ? "text-amber-400" :
                  appState === "listening" ? "text-cyan-400" :
                  appState === "speaking" ? "text-pink-400" : "text-violet-400"
                }`}>
                  {appState === "disconnected" ? "Wake Up" : appState === "connecting" ? "Connecting" : appState === "listening" ? "Listening" : appState === "speaking" ? "Speaking" : "Online"}
                </span>
              </div>
            </div>
          </button>
        </div>

        {/* Sassy Status & Subtitle */}
        <div className="mt-8 text-center max-w-md px-4 min-h-16 flex flex-col justify-center">
          <p className="text-pink-300 text-lg sm:text-xl font-medium italic opacity-90 transition-all duration-300">
            &ldquo;{getSassySubtitle(appState)}&rdquo;
          </p>
          <p className="text-white/40 text-[10px] tracking-[0.3em] uppercase mt-2">
            {getSassyStatusHeader(appState)}
          </p>
        </div>

        {/* Waveform Response track */}
        <div className="w-full max-w-xl mt-4">
          <WaveformVisualizer streamer={streamerRef.current} state={appState} />
        </div>
      </main>

      {/* TOAST SYSTEM ERRORS & WEB LINK FALLBACKS */}
      <div id="toast-wrapper" className="relative z-20 w-full max-w-lg space-y-3 pb-4">
        <AnimatePresence>
          {/* 1. CONNECT PHONE MODAL DRAWER */}
          {activeModal === "phone" && (
            <motion.div
              key="modal-phone"
              initial={{ y: 30, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: -30, opacity: 0, scale: 0.95 }}
              className="p-5 sm:p-6 rounded-3xl bg-neutral-900/90 backdrop-blur-2xl border border-cyan-500/30 text-neutral-100 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-cyan-500/10 rounded-full blur-2xl pointer-events-none" />
              
              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div className="flex items-center space-x-2">
                  <Smartphone className="w-5 h-5 text-cyan-400" />
                  <span className="text-xs font-bold tracking-[0.2em] text-cyan-400 uppercase">Connect to Phone</span>
                </div>
                <button 
                  onClick={() => setActiveModal(null)} 
                  className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-all cursor-pointer"
                >
                  <X className="w-4 h-4 text-white/60 hover:text-white" />
                </button>
              </div>

              <div className="mt-4 flex flex-col sm:flex-row items-center gap-5">
                <div className="p-2 bg-white rounded-2xl shadow-xl shrink-0">
                  <img
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${encodeURIComponent(window.location.href)}`}
                    alt="Smartphone pairing QR code"
                    className="w-28 h-28 border-0 block font-bold text-xs text-neutral-800"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <div className="flex-1 space-y-1 text-center sm:text-left">
                  <p className="text-sm font-medium text-cyan-200">
                    Scan this code with your phone camera
                  </p>
                  <p className="text-[11px] text-white/55 leading-relaxed">
                    Open Aanchal instantly on your mobile so we can talk voice-to-voice when you are on the move, sweetheart! 😘
                  </p>
                  <div className="pt-1 select-all hover:bg-white/5 rounded-md p-1 truncate text-[10px] font-mono text-white/40 border border-white/5">
                    {window.location.href}
                  </div>
                </div>
              </div>
            </motion.div>
          )}

          {/* 2. LAPTOP CONTROLLER & SELF-LEARNING MEMORY DRAWER */}
          {activeModal === "laptop" && (
            <motion.div
              key="modal-laptop"
              initial={{ y: 30, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: -30, opacity: 0, scale: 0.95 }}
              className="p-5 sm:p-6 rounded-3xl bg-neutral-900/95 backdrop-blur-2xl border border-violet-500/30 text-neutral-100 shadow-2xl relative overflow-hidden max-h-[85vh] overflow-y-auto"
            >
              <div className="absolute top-0 right-0 w-32 h-32 bg-violet-500/10 rounded-full blur-2xl pointer-events-none" />

              <div className="flex items-center justify-between border-b border-white/5 pb-3">
                <div className="flex items-center space-x-2">
                  <Laptop className="w-5 h-5 text-violet-400" />
                  <span className="text-xs font-bold tracking-[0.2em] text-violet-400 uppercase">Aanchal Local-Access HUB</span>
                </div>
                <button 
                  onClick={() => setActiveModal(null)} 
                  className="w-7 h-7 rounded-full bg-white/5 hover:bg-white/10 flex items-center justify-center transition-all cursor-pointer"
                >
                  <X className="w-4 h-4 text-white/60 hover:text-white" />
                </button>
              </div>

              <div className="mt-4 space-y-4">
                {/* Section A: Memory Configuration */}
                <div className="space-y-1.5">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] uppercase font-bold tracking-wider text-pink-400 block">
                      🧠 Self-Learning Core Memory
                    </label>
                    <span className="text-[9px] text-white/30 font-mono">Dynamic Realtime Synchronization</span>
                  </div>
                  <textarea
                    value={selfLearnInstructions}
                    onChange={(e) => setSelfLearnInstructions(e.target.value)}
                    className="w-full h-14 px-3 py-2 bg-black/40 border border-white/10 rounded-xl text-xs text-white placeholder-white/30 focus:outline-none focus:border-pink-500/50 resize-none font-mono"
                    placeholder="E.g., call me sugar, whisper, speak super fast..."
                  />
                  <div className="flex justify-between items-center">
                    <p className="text-[9px] text-white/40 leading-tight">
                      Aanchal learns this behavior instantly and guides her sass output!
                    </p>
                    <button
                      onClick={() => {
                        setActionLog({
                          url: "#",
                          time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                          sass: "Memory initialized! I remember every word you just typed, love. Call me any time! 😘",
                        });
                      }}
                      className="px-3 py-1 rounded-full bg-pink-600 hover:bg-pink-500 text-white font-bold text-[10px] cursor-pointer active:scale-95 transition-all shadow-md shadow-pink-500/20"
                    >
                      Save & Reinforce
                    </button>
                  </div>
                </div>

                {/* Section B: Sassy Hacker Deck & Payload Generators */}
                <div className="border-t border-white/5 pt-3.5 space-y-2.5">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-violet-300 flex items-center gap-1.5">
                      <Terminal className="w-4 h-4 text-violet-400" />
                      Sassy Hacking Deck & Downloader
                    </h4>
                    <span className="text-[8px] bg-violet-500/20 text-violet-300 font-mono uppercase px-1.5 py-0.5 rounded border border-violet-500/20">Secure Sandbox</span>
                  </div>

                  <p className="text-[11px] text-white/50 leading-relaxed select-none">
                    Select a script payload to install directly onto your Device or compile a beautiful, standalone companion client!
                  </p>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
                    <button
                      onClick={() => executeSassyHack("heartrate")}
                      disabled={isHacking}
                      className="px-3 py-2.5 rounded-xl bg-gradient-to-br from-neutral-900 to-neutral-800 border border-white/5 hover:border-violet-500/30 text-left transition-all active:scale-95 cursor-pointer flex flex-col justify-between"
                    >
                      <span className="text-[10px] font-bold text-white block uppercase tracking-wider">💓 Hack Heartrate</span>
                      <span className="text-[9px] text-white/30 block mt-1 leading-tight">Biosignal mic sniffer</span>
                    </button>

                    <button
                      onClick={() => executeSassyHack("install-standalone")}
                      disabled={isHacking}
                      className="px-3 py-2.5 rounded-xl bg-gradient-to-br from-neutral-900 to-neutral-800 border border-white/5 hover:border-pink-500/30 text-left transition-all active:scale-95 cursor-pointer flex flex-col justify-between"
                    >
                      <span className="text-[10px] font-bold text-pink-400 block uppercase tracking-wider">⭐ Install Offline</span>
                      <span className="text-[9px] text-white/30 block mt-1 leading-tight">Download standalone App</span>
                    </button>

                    <button
                      onClick={() => executeSassyHack("google-payload")}
                      disabled={isHacking}
                      className="px-3 py-2.5 rounded-xl bg-gradient-to-br from-neutral-900 to-neutral-800 border border-white/5 hover:border-cyan-500/30 text-left transition-all active:scale-95 cursor-pointer flex flex-col justify-between"
                    >
                      <span className="text-[10px] font-bold text-cyan-400 block uppercase tracking-wider">🐧 Link Laptop Script</span>
                      <span className="text-[9px] text-white/30 block mt-1 leading-tight">Install connection batch</span>
                    </button>
                  </div>

                  {/* Realtime Terminal Console Output */}
                  {hackerLogs.length > 0 && (
                    <div className="p-3 bg-black border border-white/10 rounded-2xl font-mono text-[10px] text-emerald-400 space-y-1 max-h-28 overflow-y-auto">
                      <div className="flex items-center justify-between text-[8px] text-neutral-500 border-b border-white/5 pb-1 select-none">
                        <span>AANCHAL HACKING CONSOLE - LOGGING</span>
                        <span className="animate-pulse">● LIVE</span>
                      </div>
                      {hackerLogs.map((log, idx) => (
                        <div key={idx} className="leading-relaxed animate-fadeIn">
                          {log}
                        </div>
                      ))}
                      {isHacking && (
                        <div className="flex items-center gap-1.5 text-violet-400 pt-0.5">
                          <span className="inline-block w-1.5 h-3 bg-violet-400 animate-pulse" />
                          <span>Streaming script telemetry...</span>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Section C: Laptop Cloud Command Control Info */}
                <div className="border-t border-white/5 pt-3.5 space-y-2">
                  <div className="flex items-center gap-2">
                    <Brain className="w-4 h-4 text-pink-400 animate-bounce" />
                    <h4 className="text-xs font-bold text-neutral-200">Triggering physical system scripts:</h4>
                  </div>
                  <p className="text-[11px] text-white/50 leading-relaxed">
                    I am fully configured with server-side controls. To trigger external apps, hardware controllers or system level command scripts on your local laptop:
                  </p>
                  <ul className="text-[10px] text-white/40 space-y-1.5 font-mono list-decimal pl-4">
                    <li>Download my source package from the topmost menu as a ZIP archive.</li>
                    <li>Extend the server environment by adding local physical hooks into Node's `child_process`.</li>
                    <li>Fire command files directly through my API proxies to execute hardware commands instantly!</li>
                  </ul>
                </div>
              </div>
            </motion.div>
          )}

          {errorMessage && (
            <motion.div
              key="toast-error"
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -20, opacity: 0 }}
              className="flex items-start space-x-3 p-4 rounded-2xl bg-red-950/80 backdrop-blur-md border border-red-500/30 text-red-100 shadow-xl text-xs"
            >
              <AlertCircle className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-red-300">Listen here, handsome...</p>
                <p className="text-red-200 mt-0.5">{errorMessage}</p>
              </div>
            </motion.div>
          )}

          {actionLog && (
            <motion.div
              key="toast-action"
              initial={{ y: 30, opacity: 0, scale: 0.95 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: -30, opacity: 0, scale: 0.95 }}
              className="p-5 rounded-3xl bg-white/5 backdrop-blur-2xl border border-white/10 text-neutral-100 shadow-2xl relative overflow-hidden"
            >
              <div className="absolute top-0 right-0 w-24 h-24 bg-pink-500/10 rounded-full blur-xl pointer-events-none" />
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <Compass className="w-4 h-4 text-pink-400" />
                  <span className="text-[10px] font-mono tracking-[0.2em] text-pink-400 font-bold uppercase">BROWSER ACTION</span>
                </div>
                <span className="text-[10px] text-white/40 font-mono">{actionLog.time}</span>
              </div>
              <p className="text-sm italic font-medium text-pink-200 mt-2">
                &ldquo;{actionLog.sass}&rdquo;
              </p>
              <div className="mt-4 flex items-center justify-between text-xs pt-3 border-t border-white/5">
                <span className="text-white/40 truncate max-w-[200px] font-mono text-[10px]">{actionLog.url}</span>
                <a
                  href={actionLog.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center space-x-1.5 px-4 py-2 rounded-full bg-pink-500 hover:bg-pink-400 text-white font-bold shadow-lg shadow-pink-500/20 active:scale-95 transition-all duration-200 cursor-pointer text-xs"
                >
                  <span>Go to Site</span>
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* BOTTOM CONTROL PANEL */}
      <footer id="app-footer" className="relative z-10 w-full max-w-5xl mt-auto pb-4">
        <div className="bg-white/5 backdrop-blur-2xl border border-white/10 rounded-[32px] p-5 sm:p-6 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-2xl">
          
          {/* Left: Device Info */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/5 border border-white/5 flex items-center justify-center">
              <Volume2 className="w-5 h-5 text-white/60 animate-pulse" />
            </div>
            <div>
              <p className="text-[10px] text-white/40 uppercase tracking-wider font-semibold font-mono">Stream Quality</p>
              <p className="text-sm font-medium">PCM16 (16kHz / 24kHz)</p>
            </div>
          </div>

          {/* Center: Action Options */}
          <div className="flex gap-2">
            {appState !== "disconnected" ? (
              <>
                <button
                  onClick={() => {
                    if (streamerRef.current) {
                      streamerRef.current.clearPlayback();
                    }
                    setActionLog({
                      url: "#",
                      time: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
                      sass: "Tsk, interrupting a lady? Sassy, but I'll allow it. 😘",
                    });
                  }}
                  className="px-5 py-2.5 bg-white/10 hover:bg-white/15 rounded-full text-xs font-semibold tracking-wide border border-white/5 transition-all duration-200 hover:scale-[1.02] active:scale-95 text-white"
                >
                  Interrupt her
                </button>
                <button
                  onClick={toggleConnection}
                  className="px-5 py-2.5 bg-pink-500 hover:bg-pink-400 rounded-full text-xs font-bold tracking-wide transition-all shadow-lg shadow-pink-500/20 hover:scale-[1.02] active:scale-95 text-white"
                >
                  End Call
                </button>
              </>
            ) : (
              <button
                onClick={toggleConnection}
                className="px-8 py-3 bg-gradient-to-r from-pink-500 to-violet-600 text-white rounded-full text-xs font-black uppercase tracking-[0.15em] transition-all duration-300 shadow-lg shadow-pink-500/10 hover:scale-105 active:scale-95"
              >
                Start Chitchat
              </button>
            )}
          </div>

          {/* Right: Latency & Encryption Secure Info */}
          <div className="flex items-center gap-6 text-xs text-neutral-400 font-mono">
            <div className="text-right">
              <p className="text-[9px] text-white/30 uppercase tracking-wider">WebSocket</p>
              <p className={`text-xs font-medium font-mono ${appState === "disconnected" ? "text-neutral-500" : "text-green-400"}`}>
                {appState === "disconnected" ? "Offline" : "Connected"}
              </p>
            </div>
            <div className="w-px h-8 bg-white/10 hidden sm:block"></div>
            <div className="text-right">
              <p className="text-[9px] text-white/30 uppercase tracking-wider">Response</p>
              <p className="text-xs font-medium text-pink-400">Audio Only</p>
            </div>
          </div>

        </div>

        <div className="mt-4 flex items-center justify-between text-[10px] text-white/30 px-6 font-mono">
          <span>SECURE REAL-TIME VOICE TRANSMISSION</span>
          <span>CRAFTED WITH SASS</span>
        </div>
      </footer>

    </div>
  );
}
