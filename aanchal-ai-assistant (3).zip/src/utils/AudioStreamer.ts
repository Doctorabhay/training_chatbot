/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export class AudioStreamer {
  private inputAudioCtx: AudioContext | null = null;
  private outputAudioCtx: AudioContext | null = null;
  private micStream: MediaStream | null = null;
  private sourceNode: MediaStreamAudioSourceNode | null = null;
  private scriptProcessor: ScriptProcessorNode | null = null;
  private activeSourceNodes: AudioBufferSourceNode[] = [];
  private nextStartTime: number = 0;

  // Analyser nodes for real-time visualization
  public micAnalyser: AnalyserNode | null = null;
  public speakerAnalyser: AnalyserNode | null = null;

  private onAudioCapturedCallback: ((base64PCM: string) => void) | null = null;
  private speakingStateListener: ((isSpeaking: boolean) => void) | null = null;
  private activeTimer: NodeJS.Timeout | null = null;

  constructor() {}

  /**
   * Initializes the input (mic) and output (speaker) audio contexts, analyzers.
   */
  public async startCapture(onAudioCaptured: (base64PCM: string) => void): Promise<void> {
    this.onAudioCapturedCallback = onAudioCaptured;

    try {
      // 1. Setup Audio Input Context at 16kHz for mic
      this.inputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 16000,
      });

      // 2. Setup Audio Output Context at 24kHz for Gemini Live speaker
      this.outputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 24000,
      });

      // 3. Setup Mic Analyzer for voice input visualization
      this.micAnalyser = this.inputAudioCtx.createAnalyser();
      this.micAnalyser.fftSize = 256;

      // 4. Setup Speaker Analyzer for Gemini response visualization
      this.speakerAnalyser = this.outputAudioCtx.createAnalyser();
      this.speakerAnalyser.fftSize = 256;

      // 5. Connect to microphone stream
      this.micStream = await navigator.mediaDevices.getUserMedia({
        audio: {
          echoCancellation: true,
          noiseSuppression: true,
          autoGainControl: true,
        },
      });

      // Check if we were stopped or destroyed while waiting for user microphone permission
      if (!this.inputAudioCtx) {
        if (this.micStream) {
          try {
            this.micStream.getTracks().forEach((track) => track.stop());
          } catch (e) {}
          this.micStream = null;
        }
        throw new Error("ABORTED");
      }

      this.sourceNode = this.inputAudioCtx.createMediaStreamSource(this.micStream);
      this.sourceNode.connect(this.micAnalyser);

      // ScriptProcessor is widely supported and runs reliably inside frames
      this.scriptProcessor = this.inputAudioCtx.createScriptProcessor(2048, 1, 1);
      this.micAnalyser.connect(this.scriptProcessor);
      this.scriptProcessor.connect(this.inputAudioCtx.destination);

      this.scriptProcessor.onaudioprocess = (e) => {
        if (!this.onAudioCapturedCallback) return;
        const inputData = e.inputBuffer.getChannelData(0);
        const pcm16Buffer = this.floatTo16BitPCM(inputData);
        const base64PCM = this.base64ArrayBuffer(pcm16Buffer);
        this.onAudioCapturedCallback(base64PCM);
      };

      // Reset playback schedule time
      this.nextStartTime = 0;
    } catch (err) {
      console.error("AudioStreamer failed to start capture:", err);
      this.stopCapture();
      throw err;
    }
  }

  /**
   * Stops mic capture and releases device resources.
   */
  public stopCapture(): void {
    if (this.scriptProcessor) {
      try {
        this.scriptProcessor.disconnect();
      } catch (e) {}
      this.scriptProcessor.onaudioprocess = null;
      this.scriptProcessor = null;
    }

    if (this.sourceNode) {
      try {
        this.sourceNode.disconnect();
      } catch (e) {}
      this.sourceNode = null;
    }

    if (this.micStream) {
      this.micStream.getTracks().forEach((track) => track.stop());
      this.micStream = null;
    }

    if (this.inputAudioCtx) {
      try {
        this.inputAudioCtx.close();
      } catch (e) {}
      this.inputAudioCtx = null;
    }

    this.micAnalyser = null;
    this.onAudioCapturedCallback = null;
  }

  /**
   * Suspends client capture temporarily (mute/idle states)
   */
  public suspendCapture() {
    if (this.inputAudioCtx && this.inputAudioCtx.state === "running") {
      this.inputAudioCtx.suspend();
    }
  }

  /**
   * Resumes client capture from suspended state
   */
  public resumeCapture() {
    if (this.inputAudioCtx && this.inputAudioCtx.state === "suspended") {
      this.inputAudioCtx.resume();
    }
  }

  /**
   * Plays a 24kHz incoming audio chunk and schedules it gaplessly.
   */
  public playAudioChunk(base64Audio: string, onSpeakingStateChange?: (isSpeaking: boolean) => void): void {
    if (onSpeakingStateChange) {
      this.speakingStateListener = onSpeakingStateChange;
    }

    if (!this.outputAudioCtx) {
      this.outputAudioCtx = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 24000,
      });
      this.speakerAnalyser = this.outputAudioCtx.createAnalyser();
      this.speakerAnalyser.fftSize = 256;
    }

    // Direct resume check if suspended
    if (this.outputAudioCtx.state === "suspended") {
      this.outputAudioCtx.resume();
    }

    const float32Array = this.base64ToFloat32(base64Audio);
    if (float32Array.length === 0) return;

    const audioBuffer = this.outputAudioCtx.createBuffer(1, float32Array.length, 24000);
    audioBuffer.copyToChannel(float32Array, 0);

    const sourceNode = this.outputAudioCtx.createBufferSource();
    sourceNode.buffer = audioBuffer;

    // Connect source to speaker analyzer before destination for visualization
    if (this.speakerAnalyser) {
      sourceNode.connect(this.speakerAnalyser);
      this.speakerAnalyser.connect(this.outputAudioCtx.destination);
    } else {
      sourceNode.connect(this.outputAudioCtx.destination);
    }

    const currentTime = this.outputAudioCtx.currentTime;
    if (this.nextStartTime < currentTime) {
      // Small buffer offset to account for network jitter
      this.nextStartTime = currentTime + 0.05;
    }

    sourceNode.start(this.nextStartTime);

    const duration = audioBuffer.duration;
    const chunkEndTime = this.nextStartTime + duration;
    this.nextStartTime = chunkEndTime;

    // Track speaking state
    if (this.speakingStateListener) {
      this.speakingStateListener(true);
      if (this.activeTimer) {
        clearTimeout(this.activeTimer);
      }
      // Calculate delay until this chunk finishes playing
      const delayMs = Math.max(0, (chunkEndTime - currentTime) * 1000);
      this.activeTimer = setTimeout(() => {
        if (this.speakingStateListener && this.outputAudioCtx) {
          const finishedTime = this.outputAudioCtx.currentTime;
          if (finishedTime >= this.nextStartTime - 0.01) {
            this.speakingStateListener(false);
          }
        }
      }, delayMs);
    }

    this.activeSourceNodes.push(sourceNode);

    sourceNode.onended = () => {
      const idx = this.activeSourceNodes.indexOf(sourceNode);
      if (idx !== -1) {
        this.activeSourceNodes.splice(idx, 1);
      }
    };
  }

  /**
   * Interrupts/cancels any spoken responses and resets the queue.
   */
  public clearPlayback(): void {
    if (this.activeTimer) {
      clearTimeout(this.activeTimer);
      this.activeTimer = null;
    }

    this.activeSourceNodes.forEach((node) => {
      try {
        node.stop();
      } catch (e) {}
    });
    this.activeSourceNodes = [];
    this.nextStartTime = 0;

    if (this.speakingStateListener) {
      this.speakingStateListener(false);
    }
  }

  /**
   * Completely terminates all audio contexts and clears resources.
   */
  public destroy(): void {
    this.stopCapture();
    this.clearPlayback();

    if (this.outputAudioCtx) {
      try {
        this.outputAudioCtx.close();
      } catch (e) {}
      this.outputAudioCtx = null;
    }
    this.speakingStateListener = null;
    this.speakerAnalyser = null;
  }

  // --- Utility conversion functions ---

  private floatTo16BitPCM(input: Float32Array): ArrayBuffer {
    const buffer = new ArrayBuffer(input.length * 2);
    const view = new DataView(buffer);
    let offset = 0;
    for (let i = 0; i < input.length; i++, offset += 2) {
      const s = Math.max(-1, Math.min(1, input[i]));
      view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
    return buffer;
  }

  private base64ArrayBuffer(arrayBuffer: ArrayBuffer): string {
    let binary = "";
    const bytes = new Uint8Array(arrayBuffer);
    const len = bytes.byteLength;
    for (let i = 0; i < len; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return window.btoa(binary);
  }

  private base64ToFloat32(base64: string): Float32Array {
    const binaryString = window.atob(base64);
    const len = binaryString.length;
    const buffer = new ArrayBuffer(len);
    const bytes = new Uint8Array(buffer);
    for (let i = 0; i < len; i++) {
      bytes[i] = binaryString.charCodeAt(i);
    }
    const int16Array = new Int16Array(buffer);
    const float32Array = new Float32Array(int16Array.length);
    for (let i = 0; i < int16Array.length; i++) {
      float32Array[i] = int16Array[i] / 32768.0;
    }
    return float32Array;
  }
}
