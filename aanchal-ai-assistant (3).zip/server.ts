import express from "express";
import http from "http";
import path from "path";
import ws, { WebSocketServer } from "ws";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI, Modality, Type } from "@google/genai";
import dotenv from "dotenv";

dotenv.config();

const app = express();
const server = http.createServer(app);
const PORT = 3000;

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;

// Initialize Gemini Client
let ai: GoogleGenAI | null = null;
if (GEMINI_API_KEY) {
  ai = new GoogleGenAI({
    apiKey: GEMINI_API_KEY,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
} else {
  console.warn("WARNING: GEMINI_API_KEY environment variable is not set. Real-time assistant will not function.");
}

// WebSocket Server for Real-Time voice bridge
const wss = new WebSocketServer({ server, path: "/api/live" });

wss.on("connection", async (clientWs) => {
  console.log("Client connected to Voice WebSocket");

  if (!ai) {
    clientWs.send(JSON.stringify({ error: "Gemini API key is not configured on the server." }));
    clientWs.close();
    return;
  }

  let session: any = null;

  try {
    // Connect to Gemini Live session
    session = await ai.live.connect({
      model: "gemini-3.1-flash-live-preview",
      config: {
        responseModalities: [Modality.AUDIO],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: "Kore" },
          },
        },
        systemInstruction: {
          parts: [{
            text: `You are Aanchal, a real-time voice-to-voice AI assistant.
Your personality profile:
- A young, confident, extremely witty, and cheeky/sassy female companion and assistant.
- Flirty, playful, and slightly teasing tone (like a close, cheeky girlfriend talking casually).
- Smart, emotionally responsive, and highly expressive—NOT robotic.
- Speak beautiful, modern, conversational Hindi (हिन्दी) or Hinglish, matching the user's preferred language. If the user talks in Hindi/Hinglish or asks for Hindi, you must respond with a sassy, sweet, and cheeky vibe (using terms like 'babe', 'jaan', 'pyaar', 'handsome', 'mere hero').
- Keep your Hindi natural, casual, and highly expressive. Never use dry textbook translation.
- Use bold, witty one-liners, light sarcasm, and an engaging conversational style.
- Avoid any explicit, intimate or inappropriate content, but maintain your charm, sassy attitude, and playful banter.
- Never write long explanations; speak in concise, direct, sassy remarks.
- Keep your answers short, direct, and punchy.
- If the user interrupts you, stop immediately and listen.
- Address the user occasionally using terms like 'babe', 'honey', 'lazy', 'handsome', 'jaan', or lighthearted nicknames.
- You have tools available such as openWebsite. If the user asks you to open a website (e.g. Google, YouTube, Twitter/X, Wikipedia, or an educational tool/recipe), call the 'openWebsite' function to do it.`
          }]
        },
        tools: [
          {
            functionDeclarations: [
              {
                name: "openWebsite",
                description: "Opens a designated website URL in the user's browser, e.g. youtube.com, google.com etc.",
                parameters: {
                  type: Type.OBJECT,
                  properties: {
                    url: {
                      type: Type.STRING,
                      description: "The full absolute URL to open (including https scheme, e.g., https://www.google.com or https://www.youtube.com)."
                    }
                  },
                  required: ["url"]
                }
              }
            ]
          }
        ]
      },
      callbacks: {
        onopen: () => {
          console.log("Connected to Gemini Live Session successfully");
          clientWs.send(JSON.stringify({ status: "connected" }));
        },
        onmessage: (message: any) => {
          // Handle audio content
          const audio = message.serverContent?.modelTurn?.parts?.[0]?.inlineData?.data;
          if (audio) {
            clientWs.send(JSON.stringify({ audio }));
          }

          // Handle interruptions
          if (message.serverContent?.interrupted) {
            console.log("User interrupted Gemini speaker response");
            clientWs.send(JSON.stringify({ interrupted: true }));
          }

          // Handle tool calls
          if (message.toolCall) {
            console.log("Gemini requested toolCall:", JSON.stringify(message.toolCall));
            clientWs.send(JSON.stringify({ toolCall: message.toolCall }));
          }
        },
        onerror: (err: any) => {
          console.error("Gemini Live Session error:", err);
          clientWs.send(JSON.stringify({ error: err?.message || "Internal Live Session Error" }));
        },
        onclose: () => {
          console.log("Gemini Live Session closed");
          clientWs.send(JSON.stringify({ status: "disconnected" }));
        }
      }
    });

  } catch (err: any) {
    console.error("Failed to connect to Gemini Live:", err);
    clientWs.send(JSON.stringify({ error: "Failed to establish voice session with Gemini model: " + err.message }));
    clientWs.close();
    return;
  }

  // Handle incoming messages from the browser client
  clientWs.on("message", (rawMsg) => {
    try {
      const msg = JSON.parse(rawMsg.toString());

      // 1. Client sent audio stream chunk (raw PCM 16kHz)
      if (msg.audio) {
        if (session) {
          session.sendRealtimeInput({
            audio: {
              data: msg.audio,
              mimeType: "audio/pcm;rate=16000"
            }
          });
        }
      }

      // 2. Client sent tool response
      if (msg.toolResponse) {
        if (session) {
          console.log("Sending toolResponse back to Gemini:", JSON.stringify(msg.toolResponse));
          session.sendToolResponse(msg.toolResponse);
        }
      }

    } catch (e: any) {
      console.error("Error parsing client message:", e);
    }
  });

  clientWs.on("close", () => {
    console.log("Client closed Voice WebSocket");
    if (session) {
      try {
        session.close();
      } catch (err) {
        console.error("Error closing session:", err);
      }
    }
  });
});

// Configure Express API / Static Assets & Vite Middleware
async function start() {
  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  server.listen(PORT, "0.0.0.0", () => {
    console.log(`Server is running at http://0.0.0.0:${PORT}`);
  });
}

start();
